﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class GameScript : MonoBehaviour {

    //모바일용 스크립트이면 true, PC용이면 false
    public bool mobile_on = false;

    //투명한 구형태의 오브젝트, 유저를 담당.
    public GameObject User;

    //다가오는 기둥, LR은 하드모드일때 기울어지는 방향.
    public GameObject Enemy_L;
    public GameObject Enemy_R;

    //아이템, 빠르게 해주는 노랑 아이템, 느리게 해주는 초록 아이템
    public GameObject Fest_Item;
    public GameObject Slow_Item;

    //우주선 모델.
    public GameObject Allow_Ship;

    //부스터 효과용 모델, 기본은 파랑색, 아이템에 따라 각각 노랑색과 초록색
    public GameObject BoostB;
    public GameObject BoostG;
    public GameObject BoostY;

    //메인 카메라. 이동방향에 따른 회면 기울기 효과를 위함.
    public Camera Main_Camera;

    //기본 전체 빛.
    public Light Directional_Light;

    //이동속도, 회피속도.
    public float Run_Speed = 100f;
    public float Avoid_Speed = 50f;
    float avoid_stats = 0f;

    //기둥의 넘어지는 속도. 최대와 최소 안에서 속도를 랜덤으로 결정.
    public float Enemy_Down_Speed_Max = 10f;
    public float Enemy_Down_Speed_Min = 1f;

    //아이템 추가 속도, 아이템 효과 약해지는 속도.
    public float Fest_Item_Plus_Speed = 10f;
    public float Slow_Item_Plus_Speed = -10f;
    public float Item_Speed_Weaken = 1;

    //기둥과 아이템의 생산속도.
    public float Spon_Delay = 0.5f;
    float spon_enemy_delay_stat = 0f;
    float spon_item_delay_stat = 0f;

    //전체 맵의 크기정보.
    public float Map_Range = 200f;
    public float Map_Close = -100f;
    public float Map_Away = 290f;

    //이지모드, 하드모드 정보.
    public float Easy_Mode_Time = 10f;
    public float Hard_Mode_Time = 10f;
    float stat_time = 0f;
    float level_time = 1f;

    //효과음, 배경음악 오브젝트.
    public GameObject Back_Ground_Sound;
    public GameObject Easy_Mode_Sound;
    public GameObject Hard_Mode_Sound;
    public GameObject Hard_Mode_Start_Sound;
    public GameObject Yellow_Get_Sound;
    public GameObject Green_Get_Sound;
    public GameObject User_Die_Sound;

    //시작화면 UI.
    public Button Start_Button;
    public Text TextLogo1;
    public Text TextLogo2;

    //게임화면 UI.
    public Text MaxSpeed;
    public Text StatsSpeed;
    public Text MinSpeed;
    public Text GetYellow;
    public Text GetGreen;
    public Text RunTime;
    public Text RunAway;
    public Text Score;

    //게임 종료 및 재시작 화면 UI.
    public Button Re_Start_Button;
    public Text EndMaxSpeed;
    public Text EndStatsSpeed;
    public Text EndMinSpeed;
    public Text EndGetYellow;
    public Text EndGetGreen;
    public Text EndRunTime;
    public Text EndRunAway;
    public Text EndScore;

    //아이템 획득, 유저 사망 이펙트용 오브젝트.
    public GameObject YellowEffect;
    public GameObject GreenEffect;
    public GameObject GrayEffect;

    //유저가 살아있음을 알려주는 오브젝트, TriggerScript의 사인을 받음.
    public GameObject User_Life_Sign;

    //기둥 구조체.
    struct enemy_t
    {
        public GameObject enemy;//오브젝트
        public bool L;//기울어짐 방향
        public float down_speed;//기울어짐 속도
    }

    //아이템 구조체.
    struct item_t
    {
        public GameObject item;//오브젝트
        public bool F;//아이템 종류
    }

    //기둥 생성 개수 설정.
    int enemy_max_number = 50;
    int enemy_stats_number = 0;
    enemy_t[] enemy_array = new enemy_t[50];

    //아이템 생성 개수 설정(노랑, 초록 합쳐서).
    int item_max_number = 50;
    int item_stats_number = 0;
    item_t[] item_array = new item_t[50];

    //게임 실행 확인용.
    bool game_play = false;

    //하드모드 실행 확인용.
    bool hard_mode = false;

    //아이템에 의한 이동속도 변화 변수.
    float user_plus_run_speed = 0;

    //우주선 관련 오브젝트.
    GameObject allow_ship;
    GameObject boostB;
    GameObject boostG;
    GameObject boostY;
    GameObject yellow_effact;
    GameObject green_effact;

    //아이템을 먹으면 변하는 부스터가 기본 부스터로 변하기 위한 시간 설정.
    float boost_time_max = 2f;
    float boost_time = 0f;

    //유저 관련 함수.
    void Create_User()
    {
        User.SetActive(true);//유저오브젝트 활성화.
    }//유저 생성.
    bool User_Is_Life()
    {
        if(User_Life_Sign.activeSelf == false)//유저사인 사망시.
        {
            return false;//유저 사망
        }
        else//사망 아니면
        {
            return true;//유저 생존
        }
    }//유저 생존 확인.
    void Accel_Control()
    {
        float accel = Input.acceleration.x;//현재 기울기 저장
        if(accel < -0.5f)//기울기가 +-0.5를 넘지 않게 함
        {
            accel = -0.5f;
        }
        if(accel > 0.5f)
        {
            accel = 0.5f;
        }
        avoid_stats = Avoid_Speed * (accel / 0.5f);//현재 기울기를 이동방향에 적용.
    }//모바일 기울기로 컨트롤.
    void User_Control()
    {
        if((Input.GetKey(KeyCode.A) && Input.GetKey(KeyCode.D)))//A, D키를 동시에 누르면 아무것도 하지 않음
        {

        }
        else if(Input.GetKey(KeyCode.A))//A키를 누르면
        {
            avoid_stats -= Avoid_Speed * 2 * Time.deltaTime;//왼쪽으로 방향을 틈
            if(avoid_stats <= -Avoid_Speed)//최대 왼쪽으로 틀었으면 최소 이동방향으로 설정
            {
                avoid_stats = -Avoid_Speed;
            }
        }
        else if(Input.GetKey(KeyCode.D))//D키를 누르면
        {
            avoid_stats += Avoid_Speed * 2 * Time.deltaTime;//오른쪽으로 방향을 틈
            if (avoid_stats >= Avoid_Speed)//최대 오른쪽으로 틀었으면 최대 이동방향으로 설정
            {
                avoid_stats = Avoid_Speed;
            }
        }
        else//이외, 이동방향이 0에 수렴하도록 변경
        {
            Avoid_Weaken();
        }
    }//PC키보드로 컨트롤.
    void Avoid_Weaken()
    {
        if (avoid_stats < 0)//이동방향이 왼쪽이면
        {
            avoid_stats += Avoid_Speed * 2 * Time.deltaTime;//오른쪽으로 틈
            if (avoid_stats > 0)//오른쪽 방향이 되면
            {
                avoid_stats = 0;//0으로.
            }
        }
        if (avoid_stats > 0)//이동방향이 오른쪽이면
        {
            avoid_stats -= Avoid_Speed * 2 * Time.deltaTime;//왼쪽으로 틈
            if (avoid_stats < 0)//왼쪽 방향이 되면
            {
                avoid_stats = 0;//0으로
            }
        }
    }//PC키보드 사용시 방향키 누름이 없을 때 이동방향이 0에 가까워지게 해줌.
    void Object_Event()
    {
        for (int f1 = 0; f1 < enemy_stats_number; f1++)//모든 기둥들을
        {
            enemy_array[f1].enemy.transform.Translate(-avoid_stats * Time.deltaTime, 0, 0);//유저 이동방향의 역방향으로 이동
        }
        for (int f1 = 0; f1 < item_stats_number; f1++)//모든 아이템들을
        {
            item_array[f1].item.transform.Translate(-avoid_stats * Time.deltaTime, 0, 0);//유저 이동방향의 역방향으로 이동
        }
    }//아이템과 기둥이 유저의 방향에 따라 역방향으로 이동.
    void Delete_User()
    {
        User.SetActive(false);//유저 비활성화
    }//유저 삭제.

    //기둥 관련 함수.
    void Create_Enemy(int num)
    {
        Vector3 vec;//위치, 회전상태를 전부 0으로.
        Quaternion qua;
        vec.x = 0; vec.y = 0; vec.z = 0;
        qua.x = 0; qua.y = 0; qua.z = 0; qua.w = 0;
        if (Random.Range(0, 2) == 0)//기둥이 왼쪽으로 기울어 질지, 오른쪽으로 기울어 질지 난수로 정함.
        {
            enemy_array[num].enemy = Instantiate(Enemy_L, vec, qua);//기둥 생성
            enemy_array[num].L = true;//기우는 방향 왼쪽
            enemy_array[num].down_speed = -Random.Range(Enemy_Down_Speed_Min, Enemy_Down_Speed_Max);//기우는 속도 난수로 정함
        }
        else
        {
            enemy_array[num].enemy = Instantiate(Enemy_R, vec, qua);//기동생성
            enemy_array[num].L = false;//기우는 방향 오른쪽.
            enemy_array[num].down_speed = Random.Range(Enemy_Down_Speed_Min, Enemy_Down_Speed_Max);//기우는 속도 난수로 정함.
        }
    }//기둥 생성.(L, R은 랜덤)
    void Init_Enemy(int num)
    {
        enemy_array[num].enemy.transform.Translate(-enemy_array[num].enemy.transform.position.x, 0, -enemy_array[num].enemy.transform.position.z);//기둥의 위치를 0, 0, 0,으로
        enemy_array[num].enemy.transform.Translate(Random.Range(-Map_Range, Map_Range), 0, Map_Away);//x는 지정 범위에서 랜덤, z는 맵 끝으로.
        enemy_array[num].enemy.transform.GetChild(0).transform.rotation = Quaternion.Euler(0, 0, 0);//기울기는 0, 0, 0으로
    }//기둥 초기화. 초기화시 맵 끝자락에서 랜덤한 위치에서 출현.
    void Spon_Enemy()
    {
        if(enemy_stats_number < enemy_max_number && spon_enemy_delay_stat < 0)//기둥이 최대 생성갯수에 도달하지 않았고 스폰할 시간이라면.
        {
            Create_Enemy(enemy_stats_number);//기둥생성.
            Init_Enemy(enemy_stats_number);//기둥 초기화
            enemy_stats_number += 1;//기둥개수 갱신
            spon_enemy_delay_stat = Spon_Delay;//기둥 스폰시간 초기화
        }
        else
        {
            spon_enemy_delay_stat -= 1 * Time.deltaTime;//스폰시간 대기.
        }
    }//기둥 최대 개수까지 기둥 생성.
    void Move_Enemy()
    {
        for(int f1 = 0; f1 < enemy_stats_number; f1++)//모든 기둥에 대하여
        {
            if(enemy_array[f1].L == true)//왼쪽으로 기울어지는 기둥이면
            {
                enemy_array[f1].enemy.transform.Translate(0, 0, -(Run_Speed + user_plus_run_speed) * Time.deltaTime);//진행속도만큼 전진.
                if(hard_mode == true && enemy_array[f1].enemy.transform.GetChild(0).transform.rotation.z < 0.7071068)//하드모드이면 기울어짐,
                {
                    enemy_array[f1].enemy.transform.GetChild(0).transform.Rotate(0, 0, enemy_array[f1].down_speed*Time.deltaTime);
                }
            }
            else//오른쪽으로 기울어지는 기둥이면
            {
                enemy_array[f1].enemy.transform.Translate(0, 0, -(Run_Speed + user_plus_run_speed) * Time.deltaTime);//위와 같음
                if (hard_mode == true && enemy_array[f1].enemy.transform.GetChild(0).transform.rotation.z > -0.7071068)
                {
                    enemy_array[f1].enemy.transform.GetChild(0).transform.Rotate(0, 0, enemy_array[f1].down_speed * Time.deltaTime);
                }
            }

            if(enemy_array[f1].enemy.transform.position.z <= Map_Close)//맵의 맨 앞까지 왔다면
            {
                Init_Enemy(f1);//기둥 초기화.
            }
        }
    }//기둥이 다가오는 이동관련.
    void Delete_Enemy()
    {
        for(int f1 = 0; f1 < enemy_stats_number; f1++)//모든 기둥
        {
            Destroy(enemy_array[f1].enemy);//삭제
        }
        enemy_stats_number = 0;//기둥개수 0으로 초기화
    }//기둥 삭제.

    //아이템 관련 함수.
    void Create_Item(int num)
    {
        Vector3 vec;//기둥 생성과 비슷함
        Quaternion qua;
        vec.x = 0; vec.y = 0; vec.z = 0;
        qua.x = 0; qua.y = 0; qua.z = 0; qua.w = 0;
        if(Random.Range(0, 2) == 0)
        {
            item_array[num].item = Instantiate(Fest_Item, vec, qua);
            item_array[num].F = true;//노랑 아이템.
        }
        else
        {
            item_array[num].item = Instantiate(Slow_Item, vec, qua);
            item_array[num].F = false;//초록 아이템.
        }
    }//아이템 생성.(노랑, 초록은 랜덤)
    void Init_Item(int num)
    {
        float x = Random.Range(-Map_Range, Map_Range);//기둥생성과 같음.
        item_array[num].item.transform.Translate(-item_array[num].item.transform.position.x, 0, -item_array[num].item.transform.position.z);
        item_array[num].item.transform.Translate(x, 0, Map_Away);
        item_array[num].item.transform.GetChild(0).transform.rotation = Quaternion.Euler(0, 0, 0);
        item_array[num].item.SetActive(true);//유저가 아이템을 먹으면 비화성이 됨으로 활성화해줌.
    }//아이템 초기화. 초기화시 아이템 액티브, 끝자락에서 랜덤한 위치에서 출현.
    void Spon_Item()
    {
        if(item_stats_number < item_max_number && spon_item_delay_stat < 0)//기둥 스폰과 같음
        {
            Create_Item(item_stats_number);
            Init_Item(item_stats_number);
            item_stats_number += 1;
            spon_item_delay_stat = Spon_Delay;
        }
        else
        {
            spon_item_delay_stat -= 1 * Time.deltaTime;
        }
    }//아이템 최대 개수까지 아이템 생성.
    void Move_Item()
    {
        for (int f1 = 0; f1 < item_stats_number; f1++)//기둥 스폰과 비슷함.
        {
            item_array[f1].item.transform.Translate(0, 0, -(Run_Speed + user_plus_run_speed) * Time.deltaTime);
            item_array[f1].item.transform.GetChild(0).transform.Rotate(10 * Time.deltaTime, 20 * Time.deltaTime, 30 * Time.deltaTime);//아이템이 계속 돌도록 함.
            if ((item_array[f1].item.transform.position.x <= 1.5 && item_array[f1].item.transform.position.x >= -1.5) &&//유저의 공간에 아이템이 다달하면, 유저가 살아있으면
                (item_array[f1].item.transform.position.z <= 1.5 && item_array[f1].item.transform.position.z >= -1.5) &&
                (item_array[f1].item.activeSelf == true))
            {
                if(item_array[f1].F == true)//유저가 먹은 아이템이 노랑이면
                {
                    user_plus_run_speed += Fest_Item_Plus_Speed;//아이템 효과 적용
                    Yellow_Boost_Get();//노랑부스터 활성화
                    Yellow_Get_Sound.SetActive(false);//노랑 아이템 획득 효과음 비활성화
                    Yellow_Get_Sound.SetActive(true);//노랑 아이템 확득 효과음 활성화
                    get_yellow +=1;//노랑아이템 획득 수 갱신
                }
                else//유저가 먹은 아이템이 초록이면
                {
                    user_plus_run_speed += Slow_Item_Plus_Speed;//위와 같음 (노랑->초록)
                    if(Run_Speed + user_plus_run_speed <= 0)//초록 아이템 효과 적용 후 이동속도가 음수이거나 0이면 유저의 이동속도는 0
                    {
                        user_plus_run_speed = -Run_Speed;
                    }
                    Green_Boost_Get();
                    Green_Get_Sound.SetActive(false);
                    Green_Get_Sound.SetActive(true);
                    get_green += 1;
                }
                item_array[f1].item.SetActive(false);//아이템을 먹었으므로 비화성화
            }
            if (item_array[f1].item.transform.position.z <= Map_Close)//아이템이 맵 앞으로 오면
            {
                Init_Item(f1);//아이템 초기화
            }
        }
    }//아이템이 다가오는 이동관련. 유저가 아이템 획득시 아이템 언액티브. 유저의 이동속도 변화, 아이템 획득 효과음 실행.
    void Delete_Item()
    {
        for (int f1 = 0; f1 < item_stats_number; f1++)//모든 아이템
        {
            Destroy(item_array[f1].item);//삭제
        }
        item_stats_number = 0;//아이템 개수 0으로 초기화
    }//아이템 삭제.

    //우주선 관련.
    void Create_Allow_Ship()
    {
        Vector3 vec;//y높이만 1로, 나머진 전부 0
        Quaternion qua;
        vec.x = 0; vec.y = 1; vec.z = 0;
        qua.x = 0; qua.y = 0; qua.z = 0; qua.w = 0;
        allow_ship = Instantiate(Allow_Ship, vec, qua);//우주선 생성
        boostB = Instantiate(BoostB, vec, qua);//부스터 종류벌료 생성.
        boostG = Instantiate(BoostG, vec, qua);
        boostY = Instantiate(BoostY, vec, qua);
        yellow_effact = Instantiate(YellowEffect, vec, qua); yellow_effact.SetActive(false);//아이템 획득 효과 오브젝트 생성 및 비활성화.
        green_effact = Instantiate(GreenEffect, vec, qua); green_effact.SetActive(false);
        Change_Boost(0);//부스터는 파랑부스터로.
    }//우주선 생성.
    void Delete_Allow_Ship()
    {
        Destroy(allow_ship);//우주선, 부스터3개, 효과 오브젝트2개 전부 삭제
        Destroy(boostB);
        Destroy(boostG);
        Destroy(boostY);
        Destroy(yellow_effact);
        Destroy(green_effact);
    }//우주선 삭제.
    void Move_Allow_Ship()
    {
        if(avoid_stats > 0)//이동방향이 오른쪽이면 오른쪽으로 모든 오브젝트 기울어짐
        {
            allow_ship.transform.rotation = Quaternion.Euler(-15.0f * (avoid_stats / Avoid_Speed), 5.0f * (avoid_stats / Avoid_Speed), -30.0f * (avoid_stats / Avoid_Speed));
            boostB.transform.rotation = Quaternion.Euler(-15.0f * (avoid_stats / Avoid_Speed), 5.0f * (avoid_stats / Avoid_Speed), -30.0f * (avoid_stats / Avoid_Speed));
            boostY.transform.rotation = Quaternion.Euler(-15.0f * (avoid_stats / Avoid_Speed), 5.0f * (avoid_stats / Avoid_Speed), -30.0f * (avoid_stats / Avoid_Speed));
            boostG.transform.rotation = Quaternion.Euler(-15.0f * (avoid_stats / Avoid_Speed), 5.0f * (avoid_stats / Avoid_Speed), -30.0f * (avoid_stats / Avoid_Speed));
            yellow_effact.transform.rotation = Quaternion.Euler(-15.0f * (avoid_stats / Avoid_Speed), 5.0f * (avoid_stats / Avoid_Speed), -30.0f * (avoid_stats / Avoid_Speed));
            green_effact.transform.rotation = Quaternion.Euler(-15.0f * (avoid_stats / Avoid_Speed), 5.0f * (avoid_stats / Avoid_Speed), -30.0f * (avoid_stats / Avoid_Speed));
       }
        else if (avoid_stats < 0)//이동방향이 왼쪽이면 왼쪽으로 모든 오브젝트 기울어짐.
        {
            allow_ship.transform.rotation = Quaternion.Euler(15.0f * (avoid_stats / Avoid_Speed), 5.0f * (avoid_stats / Avoid_Speed), -30.0f * (avoid_stats / Avoid_Speed));
            boostB.transform.rotation = Quaternion.Euler(15.0f * (avoid_stats / Avoid_Speed), 5.0f * (avoid_stats / Avoid_Speed), -30.0f * (avoid_stats / Avoid_Speed));
            boostY.transform.rotation = Quaternion.Euler(15.0f * (avoid_stats / Avoid_Speed), 5.0f * (avoid_stats / Avoid_Speed), -30.0f * (avoid_stats / Avoid_Speed));
            boostG.transform.rotation = Quaternion.Euler(15.0f * (avoid_stats / Avoid_Speed), 5.0f * (avoid_stats / Avoid_Speed), -30.0f * (avoid_stats / Avoid_Speed));
            yellow_effact.transform.rotation = Quaternion.Euler(15.0f * (avoid_stats / Avoid_Speed), 5.0f * (avoid_stats / Avoid_Speed), -30.0f * (avoid_stats / Avoid_Speed));
            green_effact.transform.rotation = Quaternion.Euler(15.0f * (avoid_stats / Avoid_Speed), 5.0f * (avoid_stats / Avoid_Speed), -30.0f * (avoid_stats / Avoid_Speed));
        }
        else//아니라면 모두 0, 0, 0
        {
            allow_ship.transform.rotation = Quaternion.Euler(0, 0, 0);
            boostB.transform.rotation = Quaternion.Euler(0, 0, 0);
            boostY.transform.rotation = Quaternion.Euler(0, 0, 0);
            boostG.transform.rotation = Quaternion.Euler(0, 0, 0);
            yellow_effact.transform.rotation = Quaternion.Euler(0, 0, 0);
            green_effact.transform.rotation = Quaternion.Euler(0, 0, 0);
        }
        Yellow_Effect_Move();//아이템 획득 효과 오브젝트 항시 On
        Green_Effect_Move();
        Move_Boost();//부스트 움직임 항시 On
    }//이동방향에 따라 우주선, 부스터, 효과오브젝트의 기울기 변화.

    //아이템 획득 효과 오브젝트 관련.
    float yellow_effect_stat_size = 0.5f; //오브젝트 최소크기.
    void Yellow_Effect_On()
    {
        yellow_effact.SetActive(true);//노랑 이팩트 활성화
        yellow_effect_stat_size = 0.5f;//크기는 0.5f부터
    }//오브젝트 활성화.
    void Yellow_Effect_Move()
    {
        yellow_effact.transform.GetChild(0).localScale = new Vector3(yellow_effect_stat_size, yellow_effect_stat_size, yellow_effect_stat_size);//최대크기 2.0f에 도달하면 오브젝트 비활성화.
        if (yellow_effect_stat_size >= 2.0f)
        {
            yellow_effact.SetActive(false);
        }
        else
        {
            yellow_effect_stat_size += 20.0f * Time.deltaTime;//아직이라면 계속 커진다.
        }
    }//활성화시 0.5f크기에서 2.0f크기로 커지며 2.0f를 넘으면 언엑티브.

    float green_effect_stat_size = 0.5f;//위와 같음.
    void Green_Effect_On()
    {

        green_effact.SetActive(true);
        green_effect_stat_size = 0.5f;
    }
    void Green_Effect_Move()
    {
        green_effact.transform.GetChild(0).localScale = new Vector3(green_effect_stat_size, green_effect_stat_size, green_effect_stat_size);
        if (green_effect_stat_size >= 2.0f)
        {
            green_effact.SetActive(false);
        }
        else
        {
            green_effect_stat_size += 20.0f * Time.deltaTime;
        }
    }

    //유저 사망 효과 오브젝트 관련.
    float gray_effect_stat_size = 0.5f;//오브젝트 최소크기.
    GameObject gray_effact;
    bool gray_effect_active = false;//오브젝트 활성화 표시.
    void Gray_Effect_Create()
    {
        Vector3 vec;//우주선 위치와 동일하게 생성
        Quaternion qua;
        vec.x = 0; vec.y = 1; vec.z = 0;
        qua.x = 0; qua.y = 0; qua.z = 0; qua.w = 0;
        gray_effact = Instantiate(GrayEffect, vec, qua); gray_effact.SetActive(false);//비활성화.
    }//오브젝트 생성.
    void Gray_Effect_On()
    {
        gray_effact.SetActive(true);//다른 이펙트 오브젝트와 같음
        gray_effect_stat_size = 0.5f;
    }//오브젝트 활성화.
    void Gray_Effect_Move()
    {
        gray_effact.transform.GetChild(0).localScale = new Vector3(gray_effect_stat_size, gray_effect_stat_size, gray_effect_stat_size);//다른 이펙트 오브젝트와 같음
        if (gray_effect_stat_size >= 2.0f)
        {
            gray_effact.SetActive(false);
            gray_effect_active = true;
        }
        else
        {
            gray_effect_stat_size += 20.0f * Time.deltaTime;
        }
    }//활성화시 0.5f크기에서 2.0f크기로 커지며 2.0f를 넘으면 언엑티브.
    void Gray_Effect_Delete()
    {
        Destroy(gray_effact);
    }//오브젝트 삭제.

    //부스터 오브젝트 관련.
    void Change_Boost(int num)
    {
        if (User_Is_Life() == true)//유저 생존시
        {
            switch (num)//들어온 변수값에 따라
            {
                case 0:
                    boostB.SetActive(true);//파랑부스트 활성화
                    boostY.SetActive(false);
                    boostG.SetActive(false);
                    break;

                case 1:
                    boostB.SetActive(false);//노랑부스트 활성화
                    boostY.SetActive(true);
                    boostG.SetActive(false);
                    Yellow_Effect_On();
                    break;

                case 2:
                    boostB.SetActive(false);//초록부스트 활성화
                    boostY.SetActive(false);
                    boostG.SetActive(true);
                    Green_Effect_On();
                    break;
            }
        }
    }//부스터 교체.
    void Yellow_Boost_Get()
    {
        Change_Boost(1);//노랑부스터로 교체
        boost_time = boost_time_max;//활성화시간 최대.
    }//노란 부스터 활성화.
    void Green_Boost_Get()
    {
        Change_Boost(2);//위와같음
        boost_time = boost_time_max;
    }//초록 부스터 확성화.
    void Blue_Boost_Get()
    {
        if(boost_time <= 0)
        {
            Change_Boost(0);//파랑 부스트 교체
        }
        else
        {
            boost_time -= 1.0f * Time.deltaTime;//음수 시간으로 설정(음수이면 기본지속)
        }
    }//다른 부스터 비활성시 파랑 부스터 활성화.
    void Move_Boost()
    {
        boostG.transform.localScale = new Vector3(1, 1, BoostB.transform.localScale.z * Random.Range(1.0f, 1.3f));//초록 부스터는 비교적 짧은 움직임
        boostB.transform.localScale = new Vector3(1, 1, BoostB.transform.localScale.z * Random.Range(1.3f, 1.6f));//파랑 부스터는 중간 움직임
        boostY.transform.localScale = new Vector3(1, 1, BoostB.transform.localScale.z * Random.Range(1.6f, 1.9f));//노랑 부스터는 빅적 긴 움직임,
    }//부스터의 움직입 관련.랜덤함수를 이용하여 길이를 바꿈.

    //카메라 관련.
    void Move_Main_Camera()
    {
        if (avoid_stats != 0)//이동방향이 직진이 아니면
        {
            Main_Camera.transform.rotation = Quaternion.Euler(0, 0, -5.0f * (avoid_stats / Avoid_Speed));//이동방향만큼 해당 방향으로 최대 5도정도 기울어짐
        }
        else
        {
            Main_Camera.transform.rotation = Quaternion.Euler(0, 0, 0);//직진이면 0으로
        }
    }//이동방향에 따라 카메라 기울기 변화.

    //아이템 효과 약화 관련.
    void Item_Speed_Weak()
    {
        if(user_plus_run_speed < 0)//아이템 효과가 음수이면
        {
            user_plus_run_speed += Item_Speed_Weaken * Time.deltaTime;//시간에따라 이동속도 강화
            if (user_plus_run_speed >= 0)//0이거나 양수이면 0으로
            {
                user_plus_run_speed = 0;
            }
        }
        else if(user_plus_run_speed > 0)//아이템 효과가 양수이면
        {
            user_plus_run_speed -= Item_Speed_Weaken * Time.deltaTime;//시간에 따라 이동속도 약화
            if (user_plus_run_speed <= 0)//0이거나 음수이면 0으로
            {
                user_plus_run_speed = 0;
            }
        }
    }

    //이지모드, 하드모드 관련.
    void Timer_Event()
    {
        if(hard_mode == false && stat_time < 0)//이지모드이고 지나간 시간이 0보다 작으면
        {
            hard_mode = true;//하드모드로 변경
            Hard_Mode_Start_Sound.SetActive(true);//이지모드 배경음 끄고 하드모드 배경음 활성화
            Hard_Mode_Sound.SetActive(true);
            Easy_Mode_Sound.SetActive(false);
            Debug.Log("Hard_Mode" + level_time);
            switch(Random.Range(0, 3))//3가지 단색 조명중 하나 선택
            {
                case 0:
                    Directional_Light.color = Color.red;
                    break;
                case 1:
                    Directional_Light.color = Color.green;
                    break;
                case 2:
                    Directional_Light.color = Color.blue;
                    break;
            }
            stat_time = Hard_Mode_Time * level_time;//하드모드 지속시간 설정
        } 
        else if(hard_mode == true && stat_time < 0)//하드모드이고 지나간 시간이 0보다 작으면
        {
            hard_mode = false;//이지모드로 변경
            Debug.Log("Easy_Mode");
            Easy_Mode_Sound.SetActive(true);//이지모드배경음 활성화, 하드모드 배경음 끔
            Hard_Mode_Start_Sound.SetActive(false);
            Hard_Mode_Sound.SetActive(false);
            Directional_Light.color = Color.gray;//배경 조명은 회색
            stat_time = Easy_Mode_Time;//이지모드 지속시간 설정
            level_time += 1;//레벨1++
        }
        else
        {
            stat_time -= Time.deltaTime;//해당사하 없으면 지속시간 -1
        }
    }//이지모드시 이지모드용 배경음 활성화, 하드모드시 하드모드용 배경음 활성화 및 배경 조명 색 변경, 이외 해당 모드의 시간이 0이 될 때까지 기다림.(이지모드 = 20초, 하드모드 = (10 * 레벨)초)

    //시작화면 관련.
    bool start_page_unhide = true;//시작화면 상태.
    void Start_Page_Hide()
    {
        if (start_page_unhide == true)//시작화면이 보임상태이면
        {
            Start_Button.transform.Translate(0, -2000, 0);//숨김으로 변경(2000만큼 내림)
            TextLogo1.transform.Translate(0, -2000, 0);
            TextLogo2.transform.Translate(0, -2000, 0);
            start_page_unhide = false;//상태변경
            Start_Button_Up();//게임시작버튼 안눌림
        }
    }//시작화면 숨김.
    void Start_Page_Unhide()
    {
        if (start_page_unhide == false)//위와 반대.
        {
            Start_Button.transform.Translate(0, 2000, 0);
            TextLogo1.transform.Translate(0, 2000, 0);
            TextLogo2.transform.Translate(0, 2000, 0);
            start_page_unhide = true;
        }
    }//시작화면 보임.

    //게임화면 관련.
    bool game_page_unhide = true;//게임화면 상태.
    float max_speed ;
    float min_speed = 0;
    float get_yellow = 0;
    float get_green = 0;
    float run_time = 0;
    float run_away = 0;
    float score = 0;
    void Game_Page_Hide()
    {
        if (game_page_unhide == true)//시작화면과 같음
        {
            MaxSpeed.transform.Translate(0, -2000, 0);
            StatsSpeed.transform.Translate(0, -2000, 0);
            MinSpeed.transform.Translate(0, -2000, 0);
            GetYellow.transform.Translate(0, -2000, 0);
            GetGreen.transform.Translate(0, -2000, 0);
            RunTime.transform.Translate(0, -2000, 0);
            RunAway.transform.Translate(0, -2000, 0);
            Score.transform.Translate(0, -2000, 0);
            game_page_unhide = false;
        }
    }//게임화면 숨김.
    void Game_Page_Unhide()
    {
        if (game_page_unhide == false)//시작화면과 같음
        {
            MaxSpeed.transform.Translate(0, 2000, 0);
            StatsSpeed.transform.Translate(0, 2000, 0);
            MinSpeed.transform.Translate(0, 2000, 0);
            GetYellow.transform.Translate(0, 2000, 0);
            GetGreen.transform.Translate(0, 2000, 0);
            RunTime.transform.Translate(0, 2000, 0);
            RunAway.transform.Translate(0, 2000, 0);
            Score.transform.Translate(0, 2000, 0);
            game_page_unhide = true;
        }
    }//게임화면 보임.
    void Game_Page_Move()
    {
        if(Run_Speed + user_plus_run_speed > max_speed)//최대 속도 갱신
        {
            max_speed = Run_Speed + user_plus_run_speed;
        }
        if(Run_Speed + user_plus_run_speed < min_speed)//최소 속도 갱신
        {
            min_speed = Run_Speed + user_plus_run_speed;
        }
        run_time += 1 * Time.deltaTime;//시간 갱신
        run_away += (Run_Speed + user_plus_run_speed) * Time.deltaTime;//이동거리 갱신
        score = ((get_yellow + get_green) * 100) + (max_speed + (Run_Speed - min_speed) + run_time + run_away/10);//스코어 갱신
        MaxSpeed.text =   "max spped  " + (int)max_speed;//텍스트 변경
        StatsSpeed.text = "sta speed  " + (int)(Run_Speed + user_plus_run_speed);
        MinSpeed.text =   "min speed  " + (int)min_speed;
        GetYellow.text =  "get yello  " + (int)get_yellow;
        GetGreen.text =   "get green  " + (int)get_green;
        RunTime.text =    (int)run_time + "  s";
        RunAway.text =    (int)run_away +"  m";
        Score.text =      "score  " + (int)score;
    }//게임화면 변수 설정 및 텍스트 설정, 스코어 계산.
    void Init_Game_Page()
    {
        max_speed = Run_Speed;//해당 변수 초기화
        min_speed = Run_Speed;
        get_yellow = 0;
        get_green = 0;
        run_time = 0;
        run_away = 0;
        score = 0;
    }//게임화면 초기화.

    //재시작화면 관련.
    bool re_page_unhide = true;//재시작화면 상태.
    float end_max_speed;
    float end_stat_speed;
    float end_min_speed;
    float end_get_yellow;
    float end_get_green;
    float end_run_time;
    float end_run_away;
    float end_score;
    void Re_Page_Hide()
    {
        if (re_page_unhide == true)//위와 같음
        {
            EndMaxSpeed.transform.Translate(0, -2000, 0);
            EndStatsSpeed.transform.Translate(0, -2000, 0);
            EndMinSpeed.transform.Translate(0, -2000, 0);
            EndGetYellow.transform.Translate(0, -2000, 0);
            EndGetGreen.transform.Translate(0, -2000, 0);
            EndRunTime.transform.Translate(0, -2000, 0);
            EndRunAway.transform.Translate(0, -2000, 0);
            EndScore.transform.Translate(0, -2000, 0);
            Re_Start_Button.transform.Translate(0, -2000, 0);
            re_page_unhide = false;
        }
    }//재시작화면 숨김.
    void Re_Page_Unhide()
    {
        if (re_page_unhide == false)//위와 같음
        {
            EndMaxSpeed.transform.Translate(0, 2000, 0);
            EndStatsSpeed.transform.Translate(0, 2000, 0);
            EndMinSpeed.transform.Translate(0, 2000, 0);
            EndGetYellow.transform.Translate(0, 2000, 0);
            EndGetGreen.transform.Translate(0, 2000, 0);
            EndRunTime.transform.Translate(0, 2000, 0);
            EndRunAway.transform.Translate(0, 2000, 0);
            EndScore.transform.Translate(0, 2000, 0);
            Re_Start_Button.transform.Translate(0, 2000, 0);
            re_page_unhide = true;
        }
    }//재시작화면 보임.
    void Re_Page_Set()
    {
        end_max_speed = max_speed;//게임화면 관련 변수들에서 값을 가져옴
        end_stat_speed = (Run_Speed + user_plus_run_speed);
        end_min_speed = min_speed;
        end_get_yellow = get_yellow;
        end_get_green = get_green;
        end_run_time = run_time;
        end_run_away = run_away;
        end_score = score;
    }//재시작화면 관련 변수 세팅.
    void Re_Page_Score()
    {
        EndMaxSpeed.text =   "max speed  " + (int)end_max_speed;//텍스트 변경
        EndStatsSpeed.text = "las speed  " + (int)end_stat_speed;
        EndMinSpeed.text =   "min speed  " + (int)end_min_speed;
        EndGetYellow.text =  "get yello  " + (int)end_get_yellow;
        EndGetGreen.text =   "get green  " + (int)end_get_green;
        EndRunTime.text =    (int)end_run_time + "  s";
        EndRunAway.text =    (int)end_run_away + "  m";
        EndScore.text =      " " + (int)end_score + " ";
    }//재시작화면 텍스트 설정.

    //게임시작 버튼 관련.
    bool start_button_down = false;//버튼 눌림.
    void Start_Button_Down()
    {
        start_button_down = true;
    }//버튼 누름.
    void Start_Button_Up()
    {
        start_button_down = false;
    }//버튼 안누름.

    //게임 재시작 버튼 관련.
    bool re_button_down = false;//위와 같음.
    void Re_Button_Down()
    {
        re_button_down = true;
    }
    void Re_Button_Up()
    {
        re_button_down = false;
    }

    //게임 관련.
    void Init_Game()
    {
        spon_enemy_delay_stat = 0f;//기둥 생성시간 초기화
        spon_item_delay_stat = 0f;//아이템 생성시간 초기화
        user_plus_run_speed = 0f;//아이템 효과 초기화
        Create_User();//유저생성
        Create_Allow_Ship();//우주선 생성
        game_play = true;//게임 시작 설정
        level_time = 1f;//레벨은 1
        stat_time = Easy_Mode_Time;//모드는 이지모드로 시작
        hard_mode = false;//하드모드 비활성화
        avoid_stats = 0f;//이동방향은 직진
        boost_time = 0f;//노랑, 초록 부스터 실행시간 초기화.
        yellow_effect_stat_size = 0.5f;//노랑 아이템 획득 효과 오브젝트 크기 초기화.
        green_effect_stat_size = 0.5f;//초록 아이템 획득효과 오브젝트 크기 초기화.
        User_Life_Sign.SetActive(true);//유저 생존 사인 오브젝트 활성화.(살아있음 상테)
        gray_effect_active = false;//사망효과오브젝트 비활성화.
        User_Die_Sound.SetActive(false);//사망효과음 비활성화.
        Back_Ground_Sound.SetActive(false);//배경음 비활성화.
        Easy_Mode_Sound.SetActive(true);//이지모드 배경음 활성화.
    }//게임 초기화.
    void Play_Game()
    {
        if (game_play == true && User_Is_Life() == true)//게임실행시 
        {
            Spon_Enemy();//기둥 생성
            Move_Enemy();//기둥 이동
            Spon_Item();//아이템 생성
            Move_Item();//아이템 이동
            Object_Event();//기둥, 아이템 이동방향에 따라 좌우로 이동.
            Move_Allow_Ship();//우주선 기울기 변화
            Move_Main_Camera();//카메라 기울기 변화
            if (mobile_on == true)//모바일이면
            {
                Accel_Control();//기울기로 컨트롤
            }
            else//PC이면
            {
                User_Control();//키보드로 컨트롤
            }
            Item_Speed_Weak();//아이템 효과 약화
            Timer_Event();//모드변경 감지
            Blue_Boost_Get();//기본 파랑부스트 활성화.
            Game_Page_Move();//게임화면 실행
            Re_Page_Set();//재시작화면 텍스트 실시간 갱신
        }
        else//게임실행 아님 또는 게임 종료
        {
            Back_Ground_Sound.SetActive(true);//배경음 외에 모든 효과음 비활성화.
            Hard_Mode_Sound.SetActive(false);
            Hard_Mode_Start_Sound.SetActive(false);
            Easy_Mode_Sound.SetActive(false);
            Yellow_Get_Sound.SetActive(false);
            Green_Get_Sound.SetActive(false);
            Spon_Enemy();//기둥과 아이템은 계속 나오도록 설정
            Move_Enemy();
            Spon_Item();
            Move_Item();
            Move_Main_Camera();
            Object_Event();
            Delete_Allow_Ship();
            Avoid_Weaken();
            Game_Page_Hide();//게임화면 숨기고, 재시작화면 활성화.
            Re_Page_Unhide();
            Re_Page_Score();//재시작화면 점수 설정.
            if (gray_effect_active == false && game_play == true)//유저 사망 효과 관련, 게임종료일때만 실행
            {
                Gray_Effect_Create();//사망효과 오브젝트 생성.
                Gray_Effect_On();//오브젝트 활성화.
                gray_effect_active = true;//오브젝트 상태 설정.
                User_Die_Sound.SetActive(true);//사망 효과음 활성화,
            }
            else if (gray_effect_active == true && gray_effact.transform.localScale.x >= 2.0f)//사망 효과 오브젝트가 최대크기가 되면
            {
                Gray_Effect_Delete();//오브젝트 삭제
            }
            else if (gray_effect_active == true && gray_effact.transform.localScale.x < 2.0f)//그렇지 않다면.
            {
                Gray_Effect_Move();//오브젝트 커짐.
            }
            if (Input.GetKey(KeyCode.R) || start_button_down == true || re_button_down == true)//R키를 누르거나 재시작버튼 누름시
            {
                End_Game();//게임 종료(각종 오브젝트 삭제)
                Init_Game();//게임 초기화.
                Start_Page_Hide();//게임 시작화면 숨김
                Re_Page_Hide();//재시작화면 숨김.
                Game_Page_Unhide();//게임화면 활성화
                Init_Game_Page();//게임화면 초기화
                Start_Button_Up();//게임시작버튼 안눌림
                Re_Button_Up();//재시작버튼 안눌림.
            }
        }
    }//게임 진행.
    void End_Game()
    {
        Delete_User();//유저 오브젝트 삭제
        Delete_Enemy();//모든 기둥 삭제
        Delete_Item();//모든 아이템 삭제.
        Directional_Light.color = Color.gray;//배경조명 회색.
    }//게임 종료.

    // Use this for initialization
    void Start () {//프로그램 시작 전 초기화.
        Directional_Light.color = Color.gray;//배경 조명은 회색(흰색으로보임, 풀 화이트로 하면 배경이 안보임)
        Start_Button.onClick.AddListener(Start_Button_Down);//시작버튼 누름 감지
        Re_Start_Button.onClick.AddListener(Re_Button_Down);//재시작버튼 누름 감지

        Game_Page_Hide();//게임화면 숨김
        Re_Page_Hide();//재시작화면 숨김.
        Start_Page_Unhide();//시작화면 보임.
        User.SetActive(false);//유저 오브젝트 숨김
        User_Life_Sign.SetActive(false);//유저 생전관현 오브젝트 비활성화.
        Yellow_Get_Sound.SetActive(false);//노란 아이템 획득 효과음 비활성화.
        Green_Get_Sound.SetActive(false);//초록 아이템 획득 효과음 비활성화.
        Easy_Mode_Sound.SetActive(false);//이지모드 배경음 비활성화.
        Hard_Mode_Sound.SetActive(false);//하드모드 배경음 비활성화.
        Hard_Mode_Start_Sound.SetActive(false);
        User_Die_Sound.SetActive(false);//유저 사망 효과음 비활성화.
        Back_Ground_Sound.SetActive(true);//배경음 비활성화.
        game_play = false;//게임실행 no
    }
	
	// Update is called once per frame
	void Update () {
        Play_Game();//게임 실행.
        if (game_play == false)//게임 실행이 아니면 시작화면 보임.
        {
            Start_Page_Unhide();
            Game_Page_Hide();
            Re_Page_Hide();
        }
    }
}